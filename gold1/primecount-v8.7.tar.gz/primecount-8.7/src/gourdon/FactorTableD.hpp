///
/// @file  FactorTableD.hpp
/// @brief The FactorTableD class combines the lpf[n] (least prime
///        factor), mpf[n] (max prime factor) and mu[n] (Möbius
///        function) lookup tables into a single factor[n] lookup
///        table which furthermore only contains entries for numbers
///        which are not divisible by 2, 3, 5, 7 and 11. The factor[n]
///        lookup table uses up to 21 times less memory than the
///        lpf[n], mpf[n] and mu[n] lookup tables! factor[n] uses only
///        2 or 4 bytes per entry.
///
///        The factor table concept was devised and implemented by
///        Christian Bau in 2003. Note that Tomás Oliveira e Silva
///        also suggests combining the mu[n] and lpf[n] lookup tables
///        in his paper. However Christian Bau's FactorTable data
///        structure uses only half as much memory and is also
///        slightly more efficient (uses fewer instructions) than the
///        data structure proposed by Tomás Oliveira e Silva.
///
///        factor[n] stores the index pi(lpf) of the least prime
///        factor and the Möbius sign. As pi(lpf) is far smaller
///        than lpf this allows 2 byte entries up to a much larger n:
///
///        1) INT_MAX - 1    if n = 1
///        2) INT_MAX        if n is a prime
///        3) 0              if n has a prime factor > y
///        4) 0              if moebius(n) = 0
///        5) 2*pi(lpf)      if moebius(n) = 1
///        6) 2*pi(lpf) + 1  if moebius(n) = -1
///
///        factor[1] = (INT_MAX - 1) because 1 contributes to the
///        sum of the ordinary leaves S1(x, a) in the
///        Lagarias-Miller-Odlyzko and Deleglise-Rivat algorithms.
///        The values above allow to replace the 1st if statement
///        below used in the D(x, y) formula by the 2nd new if
///        statement which is obviously faster.
///
///        * Old: if (mu[n] != 0 && lpf[n] > prime && mpf[n] <= y)
///        * New: if (factor[n] > 2*pi(prime) + 1)
///
///        In-depth description of the factor table data structure:
///        https://github.com/kimwalisch/primecount/blob/master/doc/Hard-Special-Leaves-SIMD-Filtering.pdf
///
/// Copyright (C) 2026 Kim Walisch, <kim.walisch@gmail.com>
///
/// This file is distributed under the BSD License. See the COPYING
/// file in the top level directory.
///

#ifndef FACTORTABLED_HPP
#define FACTORTABLED_HPP

#include <primecount.hpp>
#include <primecount-internal.hpp>
#include <BaseFactorTable.hpp>
#include <primesieve.hpp>
#include <imath.hpp>
#include <int128_t.hpp>
#include <macros.hpp>
#include <Vector.hpp>

#include <algorithm>
#include <stdint.h>

namespace {

using namespace primecount;

template <typename T>
class FactorTableD : public BaseFactorTable
{
public:
  static_assert(sizeof(T) == sizeof(uint16_t) ||
                sizeof(T) == sizeof(uint32_t),
                "FactorTableD: T must be uint16_t or uint32_t!");

  /// Factor numbers <= z
  FactorTableD(int64_t y,
               int64_t z,
               int threads)
  {
    if_unlikely(z > max())
      throw primecount_error("z must be <= FactorTableD::max()");

    z = std::max<int64_t>(1, z);
    T T_MAX = pstd::numeric_limits<T>::max();
    factor_.resize(to_index(z) + 1);

    // mu(1) = 1.
    // 1 has zero prime factors, hence 1 has an even
    // number of prime factors. The least significant bit
    // of factor[n] stores the Möbius sign.
    factor_[0] = T_MAX ^ 1;

    int64_t sqrtz = isqrt(z);
    int64_t thread_threshold = (int64_t) 5e6;
    threads = ideal_num_threads(z, threads, thread_threshold);
    int64_t thread_dist = ceil_div(z, threads);
    thread_dist += coprime_indexes_.size() - thread_dist % coprime_indexes_.size();

    #pragma omp parallel for num_threads(threads) schedule(static, 1)
    for (int t = 0; t < threads; t++)
    {
      // Thread processes interval [low, high]
      int64_t low = thread_dist * t;
      int64_t high = low + thread_dist;
      low = std::max(first_coprime(), low + 1);
      high = std::min(high, z);

      if (low <= high)
      {
        // Default initialize memory to all bits set
        int64_t low_idx = to_index(low);
        int64_t size = (to_index(high) + 1) - low_idx;
        std::fill_n(&factor_[low_idx], size, T_MAX);

        int64_t start = first_coprime();
        int64_t stop = high / first_coprime();
        int64_t min_m = first_coprime() * first_coprime();
        primesieve::iterator it(start, stop);

        if (min_m <= high)
        {
          // PrimePi(13) = 6
          ASSERT(first_coprime() == 13);
          int64_t prime_index = 6;

          for (; true; prime_index++)
          {
            // Find multiples > prime
            int64_t i = 1;
            int64_t prime = it.next_prime();
            int64_t multiple = next_multiple(prime, low, &i);
            min_m = prime * first_coprime();

            if (min_m > high)
              break;

            for (; multiple <= high; multiple = prime * to_number(i++))
            {
              int64_t mi = to_index(multiple);
              // prime is the smallest factor of multiple
              if (factor_[mi] == T_MAX)
              {
                ASSERT(encode(prime_index) <= T_MAX - 2);
                factor_[mi] = (T) encode(prime_index);
              }
              // Toggle whether multiple has an even or odd number
              // of distinct prime factors.
              else if (factor_[mi] != 0)
                factor_[mi] ^= 1;
            }

            if (prime <= sqrtz)
            {
              int64_t j = 0;
              int64_t square = prime * prime;
              multiple = next_multiple(square, low, &j);

              // Sieve out numbers that are not square free
              // i.e. numbers for which moebius(n) = 0.
              for (; multiple <= high; multiple = square * to_number(j++))
                factor_[to_index(multiple)] = 0;
            }
          }
        }

        // Iterate over primes from [y+1, high]
        start = std::max(start, y + 1);

        if (start <= high)
        {
          it.jump_to(start, high);

          // y < prime <= z
          while (true)
          {
            int64_t i = 0;
            int64_t prime = it.next_prime();
            int64_t next = next_multiple(prime, low, &i);

            if (prime > high)
              break;

            // Sieve out primes > y &&
            // Sieve out numbers with prime factors > y
            for (; next <= high; next = prime * to_number(i++))
              factor_[to_index(next)] = 0;
          }
        }
      }
    }
  }

  /// Returns the factor table entry for the number
  /// n = to_number(index).
  ///
  /// Return value:
  ///
  /// 1) INT_MAX - 1    if n = 1
  /// 2) INT_MAX        if n is a prime
  /// 3) 0              if n has a prime factor > y
  /// 4) 0              if moebius(n) = 0
  /// 5) 2*pi(lpf)      if moebius(n) = 1
  /// 6) 2*pi(lpf) + 1  if moebius(n) = -1
  ///
  int64_t operator[](int64_t index) const
  {
    return factor_[index];
  }

  const T* data() const
  {
    return factor_.data();
  }

  /// Encode prime index for use in the factor table
  static int64_t encode(int64_t prime_index)
  {
    return prime_index * 2 + 1;
  }

  /// Get the Möbius function value of the number
  /// n = to_number(index).
  ///
  /// https://en.wikipedia.org/wiki/Möbius_function
  /// mu(n) = 1 if n is a square-free integer with an even number of prime factors.
  /// mu(n) = −1 if n is a square-free integer with an odd number of prime factors.
  /// mu(n) = 0 if n has a squared prime factor.
  ///
  int64_t mu(int64_t index) const
  {
    // mu(n) = 0 is disabled by default for performance
    // reasons, we only enable it for testing.
    #if defined(ENABLE_MU_0_TESTING)
      if (factor_[index] == 0)
        return 0;
    #else
      ASSERT(factor_[index] != 0);
    #endif

    if (factor_[index] & 1)
      return -1;
    else
      return 1;
  }

  static constexpr int64_t max()
  {
    // The least prime factor is <= sqrt(z) and with 16-bit
    // entries p(32767) = 386083 is the first prime whose
    // index cannot be encoded, hence z < 386083^2.
    return sizeof(T) == sizeof(uint16_t)
      ? 386083ll * 386083 - 1
      : pstd::numeric_limits<int64_t>::max();
  }

private:
  Vector<T> factor_;
};

} // namespace

#endif
